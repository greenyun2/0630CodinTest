import React from 'react';
import logo from './logo.svg';
import './App.css';
import Phone from './Component/Phone';

function App() {
  return (
    <div className="App">
      <h3>GMA 회원가입</h3>
      <input type="text" className="inputbox" id="email" placeholder="이메일을 입력해주세요" />
      <div className="error" id="error_email"></div>

      <input type="text" className="inputbox" id="name" placeholder="이름을 입력해주세요"/>
      <div className="error" id="error_name"></div>

    <input type="password" className="inputbox" id="password1" placeholder="비밀번호를 입력해주세요"/>
    <div className="error" id="error_password1"></div>

    <input type="password" className="inputbox" id="password2" placeholder="비밀번호를 다시 입력해주세요"/>
    <div className="error" id="error_password2"></div>

    <Phone />


    </div>
  );
}

export default App;
