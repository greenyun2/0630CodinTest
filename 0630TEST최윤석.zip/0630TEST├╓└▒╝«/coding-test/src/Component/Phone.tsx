import React, { useState } from 'react'

const Phone = () => {
  const [phone, setPhone] = useState("");
  const handleOnChangePhone = () => {
    
  }
  return (
    <div className="phone_wrapper">
      <input id="phone1" className="phoneNum" type="text"  maxLength={3} /> -
      <input id="phone2" className="phoneNum" type="text"  maxLength={4} /> -
      <input id="phone3" className="phoneNum" type="text"  maxLength={4} />
    </div>
  )
}

export default Phone